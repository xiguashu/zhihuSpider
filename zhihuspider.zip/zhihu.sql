CREATE TABLE `zhihu`.`search_topic_comment` (
  `author` VARCHAR(45) NULL,
  `related_topic` VARCHAR(45) NULL,
  `content` VARCHAR(200) NULL);


CREATE TABLE `zhihu`.`search_similar` (
  `related_topic` VARCHAR(45) NULL,
  `title` VARCHAR(150) NULL,
  `id` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `zhihu`.`search_follow` (
  `name` VARCHAR(45) NOT NULL,
  `related` VARCHAR(45) NULL,
  `type` VARCHAR(45) NULL);

CREATE TABLE `zhihu`.`search_topic` (
  `id` VARCHAR(40) NOT NULL,
  `title` VARCHAR(200) NULL,
  `link` VARCHAR(100) NULL,
  `answer_count` VARCHAR(45) NULL,
  `comment` VARCHAR(45) NULL,
  PRIMARY KEY (`id`));


CREATE TABLE `zhihu`.`search_comment` (
  `related_content` VARCHAR(45) NOT NULL,
  `content` VARCHAR(200) NULL,
  `name` VARCHAR(45) NULL
  );


CREATE TABLE `zhihu`.`search_article` (
  `key_word` VARCHAR(60) NOT NULL,
  `title` VARCHAR(200) NULL,
  `link` VARCHAR(100) NOT NULL,
  `author` VARCHAR(45) NULL,
  `voteup_count` VARCHAR(45) NULL,
  `comment_count` VARCHAR(45) NULL,
  PRIMARY KEY (`key_word`, `link`));

CREATE TABLE `zhihu`.`search_people` (
  `key_word` VARCHAR(50) NOT NULL,
  `id` VARCHAR(45) NOT NULL,
  `name` VARCHAR(45) NULL,
  `answer_count` VARCHAR(45) NULL,
  `description` VARCHAR(300) NULL,
  `article_count` VARCHAR(45) NULL,
  `educations` VARCHAR(100) NULL,
  `employments` VARCHAR(100) NULL,
  `business` VARCHAR(100) NULL,
  `columns_count` VARCHAR(45) NULL,
  `locations` VARCHAR(45) NULL,
  PRIMARY KEY (`key_word`, `id`));


CREATE TABLE `article` (
  `related_user` varchar(100) DEFAULT NULL,
  `content` varchar(2000) DEFAULT NULL,
  `title` varchar(250) NOT NULL,
  `url` varchar(300) DEFAULT NULL,
  `voteup_count` varchar(45) DEFAULT NULL,
  `comment_count` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `comments` (
  `author` varchar(45) NOT NULL,
  `content` varchar(400) NOT NULL,
  `related` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`content`,`author`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `follow` (
  `name` varchar(50) DEFAULT NULL,
  `related_user` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `similar_topic` (
  `related_topic` varchar(200) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `id` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `topic` (
  `id` varchar(50) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `link` varchar(250) DEFAULT NULL,
  `answer_count` varchar(45) DEFAULT NULL,
  `comment_count` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `topic_answer` (
  `related_topic` varchar(200) NOT NULL,
  `voteup_count` varchar(45) NOT NULL,
  `comment_count` varchar(45) DEFAULT NULL,
  `author` varchar(60) NOT NULL,
  `author_link` varchar(250) DEFAULT NULL,
  `author_introduction` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`author`,`related_topic`,`voteup_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `topic_answer_comments` (
  `author` varchar(60) NOT NULL,
  `related_answer` varchar(200) NOT NULL,
  `related_topic` varchar(200) DEFAULT NULL,
  `content` varchar(400) NOT NULL,
  PRIMARY KEY (`content`,`related_answer`,`author`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `topic_comments` (
  `author` varchar(50) DEFAULT NULL,
  `related_topic` varchar(200) NOT NULL,
  `content` varchar(400) NOT NULL,
  PRIMARY KEY (`related_topic`,`content`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `user_answer` (
  `question` varchar(100) NOT NULL,
  `question_url` varchar(100) DEFAULT NULL,
  `content` varchar(500) NOT NULL,
  `created_time` varchar(45) DEFAULT NULL,
  `related_user` varchar(60) DEFAULT NULL,
  `comment_count` varchar(45) DEFAULT NULL,
  `voteup_count` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`content`,`question`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `user_imfor` (
  `id` varchar(100) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `answer_count` varchar(25) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `articles_count` varchar(25) DEFAULT NULL,
  `columns_count` varchar(25) DEFAULT NULL,
  `educations` varchar(100) DEFAULT NULL,
  `employments` varchar(100) DEFAULT NULL,
  `business` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
